"""
This file contains all classes that have zonal or geographic properties.

Jim Hommes - 13-5-2021
"""
from domain.import_object import *


class Zone(ImportObject):
    pass


class PowerGridNode(ImportObject):
    pass
