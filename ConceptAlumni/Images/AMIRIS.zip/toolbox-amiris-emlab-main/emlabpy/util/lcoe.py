# import numpy_financial as npf
#
#
# def lcoe(annual_output, capital_cost, annual_operating_cost, discount_rate, lifetime):
#
#     annual_cost_capital = npf.pmt(discount_rate, lifetime, -capital_cost)
#     total_annual_cost = annual_cost_capital + annual_operating_cost
#
#     return total_annual_cost / annual_output


