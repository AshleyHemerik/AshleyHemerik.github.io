This folder can be used for storing original data files for the project.

If possible, add *datapackage.json* file to make it a [Data Package](https://frictionlessdata.io/data-package/).